﻿using Damacon.StoreD.DAL.Operations.Contracts;
using System;
using System.Linq;
using Damacon.StoreD.DAL.Database.EF;
using Damacon.StoreD.DAL.i18n;

namespace Damacon.StoreD.DAL.Operations.Concrete
{
    internal class StaticDataDAL : IStaticDataDAL
    {
        public GenericActionResult<Country> GetAllCountries()
        {
            GenericActionResult<Country> result = new GenericActionResult<Country>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    result.Result = context.Countries.ToList();
                    result.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = Resources.M_InternalServerError;
            }
            return result;
        }

        public GenericActionResult<UserType> GetAllUserTypes()
        {
            GenericActionResult<UserType> result = new GenericActionResult<UserType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    result.Result = context.UserTypes.ToList();
                    result.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = Resources.M_InternalServerError; ;
            }
            return result;
        }
    }
}
