﻿using Damacon.StoreD.DAL.Database.EF;
using Damacon.StoreD.DAL.i18n;
using Damacon.StoreD.DAL.Operations.Contracts;
using System;
using System.Linq;

namespace Damacon.StoreD.DAL.Operations.Concrete
{
    internal class StoreDAL: IStoreDAL
    {
        public GenericActionResult<Store> AddNew(Store newStore, UserLite addedByUser, string accessIP)
        {
            GenericActionResult<Store> addNewStoreRequestDetails = new GenericActionResult<Store>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    using (var transactionScope = context.Database.BeginTransaction())
                    {
                        newStore.LastModifyUserID = addedByUser.ID;
                        newStore.LastModifyDateTime = DateTime.Now;
                        newStore.LastModifyIP = accessIP;
                        context.Stores.Add(newStore);
                        context.SaveChanges();
                        transactionScope.Commit();
                        addNewStoreRequestDetails.SetSingleResult(newStore);
                        addNewStoreRequestDetails.IsSuccess = true;
                        //LoggerManager.Logger.Info(string.Format("Store : {0} {1}, Successfully Created.", Store.FirstName, Store.LastName));
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                addNewStoreRequestDetails.ErrorMessage = Resources.M_InternalServerError;
            }
            return addNewStoreRequestDetails;
        }

        public GenericActionResult<Store> Update(Store updateStore, UserLite updatedByUser, string accessIP)
        {
            GenericActionResult<Store> updateStoreRequestDetails = new GenericActionResult<Store>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    using (var transactionScope = context.Database.BeginTransaction())
                    {
                        Store storeDetailFromDb = context.Stores.Find(updateStore.ID);
                        if (storeDetailFromDb != null)
                        {
                            updateStore.LastModifyUserID = updatedByUser.ID;
                            updateStore.LastModifyDateTime = DateTime.Now;
                            updateStore.LastModifyIP = accessIP;
                            context.Entry(storeDetailFromDb).CurrentValues.SetValues(updateStore);
                            context.SaveChanges();
                            transactionScope.Commit();
                            updateStoreRequestDetails.SetSingleResult(storeDetailFromDb);
                            updateStoreRequestDetails.IsSuccess = true;
                            //LoggerManager.Logger.Info(string.Format("Store : {0} {1}, Successfully Updated.", StoreDetail.FirstName, StoreDetail.LastName));
                        }
                        else
                        {
                            updateStoreRequestDetails.ErrorMessage = Resources.M_InternalServerError;
                            transactionScope.Rollback();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                updateStoreRequestDetails.ErrorMessage = Resources.M_InternalServerError;
            }
            return updateStoreRequestDetails;
        }

        public GenericActionResult<Store> GetById(int storeid)
        {
            GenericActionResult<Store> result = new GenericActionResult<Store>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    result.Result = context.Stores.Where(x => x.ID == storeid).ToList();
                    if (result.Result.Count() > 0)
                    {
                        result.IsSuccess = true;
                    }
                    else
                    {
                        result.ErrorMessage = "";
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = "";
            }
            return result;
        }

        public GenericActionResult<Store> GetAll(bool isGetDeleted)
        {
            GenericActionResult<Store> result = new GenericActionResult<Store>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    if (isGetDeleted)
                    {
                        result.Result = context.Stores.ToList();
                    }
                    else
                    {
                        result.Result = context.Stores.Where(x => x.Deleted == false).ToList();
                    }
                    result.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = Resources.M_InternalServerError;
            }
            return result;
        }
    }
}
