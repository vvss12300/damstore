﻿using Damacon.StoreD.DAL.Database.EF;
using Damacon.StoreD.DAL.i18n;
using Damacon.StoreD.DAL.Operations.Contracts;
using System;
using System.Linq;

namespace Damacon.StoreD.DAL.Operations.Concrete
{
    internal class WorkerTimeTypeDAL: IWorkerTimeTypeDAL
    {
        public GenericActionResult<WorkerTimeType> AddNew(WorkerTimeType newWorkerTimeType, UserLite addedByUser, string accessIP)
        {
            GenericActionResult<WorkerTimeType> addNewWorkerTimeTypeRequestDetails = new GenericActionResult<WorkerTimeType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    using (var transactionScope = context.Database.BeginTransaction())
                    {
                        WorkerTimeType workerTimeTypeDetail = context.WorkerTimeTypes.FirstOrDefault(u => u.TypeText.Equals(newWorkerTimeType.TypeText, StringComparison.InvariantCultureIgnoreCase));
                        if (workerTimeTypeDetail == null)
                        {
                            newWorkerTimeType.LastModifyUserID = addedByUser.ID;
                            newWorkerTimeType.LastModifyDateTime = DateTime.Now;
                            newWorkerTimeType.LastModifyIP = accessIP;
                            context.WorkerTimeTypes.Add(newWorkerTimeType);
                            context.SaveChanges();
                            transactionScope.Commit();
                            addNewWorkerTimeTypeRequestDetails.SetSingleResult(newWorkerTimeType);
                            addNewWorkerTimeTypeRequestDetails.IsSuccess = true;
                            //LoggerManager.Logger.Info(string.Format("WorkerTimeType : {0} {1}, Successfully Created.", WorkerTimeType.FirstName, WorkerTimeType.LastName));
                        }
                        else
                        {
                            addNewWorkerTimeTypeRequestDetails.ErrorMessage = Resources.M_WorkerTimeTypeAlreadyExist;
                            transactionScope.Rollback();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                addNewWorkerTimeTypeRequestDetails.ErrorMessage = Resources.M_InternalServerError;
            }
            return addNewWorkerTimeTypeRequestDetails;
        }

        public GenericActionResult<WorkerTimeType> Update(WorkerTimeType updateWorkerTimeType, UserLite updatedByUser, string accessIP)
        {
            GenericActionResult<WorkerTimeType> updateWorkerTimeTypeRequestDetails = new GenericActionResult<WorkerTimeType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    using (var transactionScope = context.Database.BeginTransaction())
                    {
                        WorkerTimeType workerTimeTypeDetailFromDb = context.WorkerTimeTypes.Find(updateWorkerTimeType.ID);
                        if (workerTimeTypeDetailFromDb != null)
                        {
                            updateWorkerTimeType.LastModifyUserID = updatedByUser.ID;
                            updateWorkerTimeType.LastModifyDateTime = DateTime.Now;
                            updateWorkerTimeType.LastModifyIP = accessIP;
                            context.Entry(workerTimeTypeDetailFromDb).CurrentValues.SetValues(updateWorkerTimeType);
                            context.SaveChanges();
                            transactionScope.Commit();
                            updateWorkerTimeTypeRequestDetails.SetSingleResult(workerTimeTypeDetailFromDb);
                            updateWorkerTimeTypeRequestDetails.IsSuccess = true;
                            //LoggerManager.Logger.Info(string.Format("WorkerTimeType : {0} {1}, Successfully Updated.", WorkerTimeTypeDetail.FirstName, WorkerTimeTypeDetail.LastName));
                        }
                        else
                        {
                            updateWorkerTimeTypeRequestDetails.ErrorMessage = Resources.M_InternalServerError;
                            transactionScope.Rollback();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                updateWorkerTimeTypeRequestDetails.ErrorMessage = Resources.M_InternalServerError;
            }
            return updateWorkerTimeTypeRequestDetails;
        }

        public GenericActionResult<WorkerTimeType> GetById(int workerTimeTypeid)
        {
            GenericActionResult<WorkerTimeType> result = new GenericActionResult<WorkerTimeType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    result.Result = context.WorkerTimeTypes.Where(x => x.ID == workerTimeTypeid).ToList();
                    if (result.Result.Count() > 0)
                    {
                        result.IsSuccess = true;
                    }
                    else
                    {
                        result.ErrorMessage = "";
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = "";
            }
            return result;
        }

        public GenericActionResult<WorkerTimeType> GetAll(bool isGetDeleted)
        {
            GenericActionResult<WorkerTimeType> result = new GenericActionResult<WorkerTimeType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    if (isGetDeleted)
                    {
                        result.Result = context.WorkerTimeTypes.ToList();
                    }
                    else
                    {
                        result.Result = context.WorkerTimeTypes.Where(x => x.Deleted == false).ToList();
                    }
                    result.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = Resources.M_InternalServerError;
            }
            return result;
        }
    }
}
