﻿using Damacon.StoreD.DAL.Database.EF;
using Damacon.StoreD.DAL.i18n;
using Damacon.StoreD.DAL.Operations.Contracts;
using System;
using System.Linq;

namespace Damacon.StoreD.DAL.Operations.Concrete
{
    internal class GoodsTypeDAL : IGoodsTypeDAL
    {
        public GenericActionResult<GoodsType> AddNew(GoodsType newGoodsType, UserLite addedByUser, string accessIP)
        {
            GenericActionResult<GoodsType> addNewGoodsTypeRequestDetails = new GenericActionResult<GoodsType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    using (var transactionScope = context.Database.BeginTransaction())
                    {
                        GoodsType goodsTypeDetail = context.GoodsType_.FirstOrDefault(u => u.TypeText.Equals(newGoodsType.TypeText, StringComparison.InvariantCultureIgnoreCase));
                        if (goodsTypeDetail == null)
                        {
                            newGoodsType.LastModifyUserID = addedByUser.ID;
                            newGoodsType.LastModifyDateTime = DateTime.Now;
                            newGoodsType.LastModifyIP = accessIP;
                            context.GoodsType_.Add(newGoodsType);
                            context.SaveChanges();
                            transactionScope.Commit();
                            addNewGoodsTypeRequestDetails.SetSingleResult(newGoodsType);
                            addNewGoodsTypeRequestDetails.IsSuccess = true;
                            //LoggerManager.Logger.Info(string.Format("GoodsType : {0} {1}, Successfully Created.", GoodsType.FirstName, GoodsType.LastName));
                        }
                        else
                        {
                            addNewGoodsTypeRequestDetails.ErrorMessage = Resources.M_GoodsTypeAlreadyExist;
                            transactionScope.Rollback();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                addNewGoodsTypeRequestDetails.ErrorMessage = Resources.M_InternalServerError;
            }
            return addNewGoodsTypeRequestDetails;
        }

        public GenericActionResult<GoodsType> Update(GoodsType updateGoodsType, UserLite updatedByUser, string accessIP)
        {
            GenericActionResult<GoodsType> updateGoodsTypeRequestDetails = new GenericActionResult<GoodsType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    using (var transactionScope = context.Database.BeginTransaction())
                    {
                        GoodsType goodsTypeDetailFromDb = context.GoodsType_.Find(updateGoodsType.ID);
                        if (goodsTypeDetailFromDb != null)
                        {
                            updateGoodsType.LastModifyUserID = updatedByUser.ID;
                            updateGoodsType.LastModifyDateTime = DateTime.Now;
                            updateGoodsType.LastModifyIP = accessIP;
                            context.Entry(goodsTypeDetailFromDb).CurrentValues.SetValues(updateGoodsType);
                            context.SaveChanges();
                            transactionScope.Commit();
                            updateGoodsTypeRequestDetails.SetSingleResult(goodsTypeDetailFromDb);
                            updateGoodsTypeRequestDetails.IsSuccess = true;
                            //LoggerManager.Logger.Info(string.Format("GoodsType : {0} {1}, Successfully Updated.", GoodsTypeDetail.FirstName, GoodsTypeDetail.LastName));
                        }
                        else
                        {
                            updateGoodsTypeRequestDetails.ErrorMessage = Resources.M_InternalServerError;
                            transactionScope.Rollback();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                updateGoodsTypeRequestDetails.ErrorMessage = Resources.M_InternalServerError;
            }
            return updateGoodsTypeRequestDetails;
        }

        public GenericActionResult<GoodsType> GetById(int goodsTypeid)
        {
            GenericActionResult<GoodsType> result = new GenericActionResult<GoodsType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    result.Result = context.GoodsType_.Where(x => x.ID == goodsTypeid).ToList();
                    if (result.Result.Count() > 0)
                    {
                        result.IsSuccess = true;
                    }
                    else
                    {
                        result.ErrorMessage = "";
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = "";
            }
            return result;
        }

        public GenericActionResult<GoodsType> GetAll(bool isGetDeleted)
        {
            GenericActionResult<GoodsType> result = new GenericActionResult<GoodsType>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    if (isGetDeleted)
                    {
                        result.Result = context.GoodsType_.ToList();
                    }
                    else
                    {
                        result.Result = context.GoodsType_.Where(x => x.Deleted == false).ToList();
                    }
                    result.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = Resources.M_InternalServerError;
            }
            return result;
        }
    }
}
