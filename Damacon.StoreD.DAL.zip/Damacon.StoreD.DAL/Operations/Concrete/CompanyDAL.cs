﻿using Damacon.StoreD.DAL.Operations.Contracts;
using System;
using System.Linq;
using Damacon.StoreD.DAL.Database.EF;
using Damacon.StoreD.DAL.i18n;

namespace Damacon.StoreD.DAL.Operations.Concrete
{
    internal class CompanyDAL : ICompanyDAL
    {
        public GenericActionResult<Company> AddNew(Company newCompany, UserLite addedByUser, string accessIP)
        {
            GenericActionResult<Company> addNewCompanyRequestDetails = new GenericActionResult<Company>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    using (var transactionScope = context.Database.BeginTransaction())
                    {
                        Company companyDetail = context.Companies.FirstOrDefault(u => u.CompanyName.Equals(newCompany.CompanyName, StringComparison.OrdinalIgnoreCase));
                        if (companyDetail == null)
                        {
                            newCompany.LastModifyUserID = addedByUser.ID;
                            newCompany.LastModifyDateTime = DateTime.Now;
                            newCompany.LastModifyIP = accessIP;
                            context.Companies.Add(newCompany);
                            context.SaveChanges();
                            transactionScope.Commit();
                            addNewCompanyRequestDetails.SetSingleResult(newCompany);
                            addNewCompanyRequestDetails.IsSuccess = true;
                            //LoggerManager.Logger.Info(string.Format("Company : {0} {1}, Successfully Created.", Company.FirstName, Company.LastName));
                        }
                        else
                        {
                            addNewCompanyRequestDetails.ErrorMessage = Resources.M_CompanyAlreadyExist;
                            transactionScope.Rollback();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                addNewCompanyRequestDetails.ErrorMessage = Resources.M_InternalServerError;
            }
            return addNewCompanyRequestDetails;
        }

        public GenericActionResult<Company> Update(Company updateCompany, UserLite updatedByUser, string accessIP)
        {
            GenericActionResult<Company> updateCompanyRequestDetails = new GenericActionResult<Company>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    using (var transactionScope = context.Database.BeginTransaction())
                    {
                        Company companyDetailFromDb = context.Companies.Find(updateCompany.ID);
                        if (companyDetailFromDb != null)
                        {
                            updateCompany.LastModifyUserID = updatedByUser.ID;
                            updateCompany.LastModifyDateTime = DateTime.Now;
                            updateCompany.LastModifyIP= accessIP;
                            context.Entry(companyDetailFromDb).CurrentValues.SetValues(updateCompany);
                            context.SaveChanges();
                            transactionScope.Commit();
                            updateCompanyRequestDetails.SetSingleResult(companyDetailFromDb);
                            updateCompanyRequestDetails.IsSuccess = true;
                            //LoggerManager.Logger.Info(string.Format("Company : {0} {1}, Successfully Updated.", CompanyDetail.FirstName, CompanyDetail.LastName));
                        }
                        else
                        {
                            updateCompanyRequestDetails.ErrorMessage = Resources.M_InternalServerError;
                            transactionScope.Rollback();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                updateCompanyRequestDetails.ErrorMessage = Resources.M_InternalServerError;
            }
            return updateCompanyRequestDetails;
        }

        public GenericActionResult<Company> GetById(int companyid)
        {
            GenericActionResult<Company> result = new GenericActionResult<Company>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    result.Result = context.Companies.Where(x => x.ID == companyid).ToList();
                    if (result.Result.Count() > 0)
                    {
                        result.IsSuccess = true;
                    }
                    else
                    {
                        result.ErrorMessage = "";
                    }
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = "";
            }
            return result;
        }

        public GenericActionResult<Company> GetAll(bool isGetDeleted)
        {
            GenericActionResult<Company> result = new GenericActionResult<Company>();
            try
            {
                using (StoreDModelEntities context = new StoreDModelEntities())
                {
                    if (isGetDeleted)
                    {
                        result.Result = context.Companies.ToList();
                    }
                    else
                    {
                        result.Result = context.Companies.Where(x => x.Deleted == false).ToList();
                    }
                    result.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                //LoggerManager.Logger.Error(ex);
                result.ErrorMessage = Resources.M_InternalServerError;
            }
            return result;
        }
    }
}
