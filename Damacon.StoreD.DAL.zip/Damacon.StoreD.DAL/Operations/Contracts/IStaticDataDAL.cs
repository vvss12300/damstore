﻿using Damacon.StoreD.DAL.Database.EF;

namespace Damacon.StoreD.DAL.Operations.Contracts
{
    public interface IStaticDataDAL
    {
        GenericActionResult<UserType> GetAllUserTypes();
        GenericActionResult<Country> GetAllCountries();
    }
}
