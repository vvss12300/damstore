﻿using Damacon.StoreD.DAL.Database.EF;

namespace Damacon.StoreD.DAL.Operations.Contracts
{
    public interface IUserDAL : ICrudBaseDAL<User>
    {
        GenericActionResult<UserLite> VerifyUserCredentials(string username, string password, string accessIP);
        GenericActionResult<ApplicationLink> GetAllUserTypeLoginPages(int userTypeId);
    }
}
