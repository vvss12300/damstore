﻿using Damacon.StoreD.DAL.Database.EF;

namespace Damacon.StoreD.DAL.Operations.Contracts
{
    public interface ICrudBaseDAL<T>
    {
        GenericActionResult<T> AddNew(T newRecord, UserLite addedByUser, string accessIP);
        GenericActionResult<T> Update(T updateUser, UserLite updatedByUser, string accessIP);
        GenericActionResult<T> GetById(int id);
        GenericActionResult<T> GetAll(bool isGetDeleted);
    }
}
