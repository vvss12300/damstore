﻿using Damacon.StoreD.DAL.Database.EF;

namespace Damacon.StoreD.DAL.Operations.Contracts
{
    public interface IWorkerTimeTypeDAL :ICrudBaseDAL<WorkerTimeType>
    {
    }
}
