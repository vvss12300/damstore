﻿CREATE TABLE [dbo].[ApplicationLink](
	[ID] [int] NOT NULL,
	[DisplayOrder] [int] NOT NULL,
	[LanguageResourceID] [nvarchar](50) NOT NULL,
	[GroupName] [nvarchar](50) NOT NULL,
	[LinkController] [nvarchar](50) NOT NULL,
	[LinkAction] [nvarchar](50) NOT NULL,
	[Disable] [bit] NOT NULL,
 CONSTRAINT [PK__Applicat__3214EC27E3C06ABA] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ApplicationLinkUserTypePermission]    Script Date: 1/4/2018 7:18:22 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ApplicationLinkUserTypePermission](
	[ApplicationLinkId] [int] NOT NULL,
	[UserTypeId] [bigint] NOT NULL,
	[Disable] [bit] NOT NULL
) ON [PRIMARY]
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (101, 1, N'HM_Users', N'TABLE', N'Manage', N'ManageUsers', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (102, 2, N'HM_Companies', N'TABLE', N'Manage', N'ManageCompanies', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (103, 3, N'HM_Stores', N'TABLE', N'Manage', N'ManageStores', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (104, 4, N'HM_Employees', N'TABLE', N'Manage', N'ManageEmployees', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (105, 5, N'HM_Buyer', N'TABLE', N'Manage', N'ManageBuyer', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (106, 6, N'HM_Supplier', N'TABLE', N'Manage', N'ManageSupplier', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (107, 7, N'HM_Documents', N'TABLE', N'Manage', N'ManageDocuments', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (108, 8, N'HM_Goods', N'TABLE', N'Manage', N'ManageGoods', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (109, 9, N'HM_WorkersTypeTime', N'TABLE', N'Manage', N'ManageWorkersTypeTime', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (201, 1, N'HM_Summary', N'STORE', N'Store', N'Summary', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (202, 2, N'HM_Sales', N'STORE', N'Store', N'Sales', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (203, 3, N'HM_WorkersTime', N'STORE', N'Store', N'WorkersTime', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (204, 4, N'HM_DocumentsRegistration', N'STORE', N'Store', N'DocumentsRegisteration', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (205, 5, N'HM_FidelityCardsAndBonus', N'STORE', N'Store', N'Fidelity', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (206, 6, N'HM_WorkersTimetable', N'STORE', N'Store', N'WorkersTimetable', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (207, 7, N'HM_WindowsDresser', N'STORE', N'Store', N'WindowsDresser', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (301, 1, N'HM_Dashboard', N'Reports', N'Reports', N'Dashboard', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (302, 2, N'HM_Report', N'Reports', N'Reports', N'Report', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (401, 1, N'HM_Periods', N'Settings', N'Settings', N'Periods', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (402, 2, N'HM_EmailServices', N'Settings', N'Settings', N'EmailServices', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (403, 3, N'HM_WindowsDresser', N'Settings', N'Settings', N'WindowsDresser', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (404, 4, N'HM_Languages', N'Settings', N'Settings', N'Languages', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (405, 5, N'HM_Backup', N'Settings', N'Settings', N'Backup', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (406, 6, N'HM_Report', N'Settings', N'Settings', N'Report', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (501, 1, N'HM_Version', N'About', N'About', N'Version', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (502, 2, N'HM_Damacon_srl', N'About', N'About', N'Damaconsrl', 0)
GO
INSERT [dbo].[ApplicationLink] ([ID], [DisplayOrder], [LanguageResourceID], [GroupName], [LinkController], [LinkAction], [Disable]) VALUES (503, 3, N'HM_RemoteConnection', N'About', N'About', N'RemoteConnection', 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (101, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (102, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (103, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (104, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (105, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (106, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (107, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (108, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (109, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (201, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (202, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (203, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (204, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (205, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (206, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (207, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (301, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (302, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (401, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (402, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (403, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (404, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (405, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (501, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (502, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (503, 1, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (101, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (102, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (103, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (104, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (105, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (106, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (107, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (108, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (109, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (201, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (202, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (203, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (204, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (205, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (206, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (207, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (301, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (302, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (501, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (502, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (503, 2, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (202, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (203, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (204, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (205, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (206, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (207, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (301, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (302, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (501, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (502, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (503, 3, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (207, 4, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (501, 4, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (502, 4, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (503, 4, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (101, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (102, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (103, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (104, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (105, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (106, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (107, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (108, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (109, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (201, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (202, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (203, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (204, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (205, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (206, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (207, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (301, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (302, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (401, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (402, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (403, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (404, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (405, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (501, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (502, 5, 0)
GO
INSERT [dbo].[ApplicationLinkUserTypePermission] ([ApplicationLinkId], [UserTypeId], [Disable]) VALUES (503, 5, 0)
GO
ALTER TABLE [dbo].[ApplicationLink] ADD  CONSTRAINT [DF_ApplicationLink_IsActive]  DEFAULT ((0)) FOR [Disable]
GO
ALTER TABLE [dbo].[ApplicationLinkUserTypePermission] ADD  CONSTRAINT [DF_ApplicationLinkUserTypePermission_Disable]  DEFAULT ((0)) FOR [Disable]
GO
ALTER TABLE [dbo].[ApplicationLink]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationLink_LanguageResource] FOREIGN KEY([LanguageResourceID])
REFERENCES [dbo].[LanguageResource] ([ResourceKey])
GO
ALTER TABLE [dbo].[ApplicationLink] CHECK CONSTRAINT [FK_ApplicationLink_LanguageResource]
GO
ALTER TABLE [dbo].[ApplicationLinkUserTypePermission]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationLinkUserTypePermission_ApplicationLink] FOREIGN KEY([ApplicationLinkId])
REFERENCES [dbo].[ApplicationLink] ([ID])
GO
ALTER TABLE [dbo].[ApplicationLinkUserTypePermission] CHECK CONSTRAINT [FK_ApplicationLinkUserTypePermission_ApplicationLink]
GO
ALTER TABLE [dbo].[ApplicationLinkUserTypePermission]  WITH CHECK ADD  CONSTRAINT [FK_ApplicationLinkUserTypePermission_UserType] FOREIGN KEY([UserTypeId])
REFERENCES [dbo].[UserType] ([ID])
GO
ALTER TABLE [dbo].[ApplicationLinkUserTypePermission] CHECK CONSTRAINT [FK_ApplicationLinkUserTypePermission_UserType]
GO
