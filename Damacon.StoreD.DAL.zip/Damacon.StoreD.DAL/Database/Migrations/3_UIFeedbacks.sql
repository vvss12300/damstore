﻿update [user] set [CountryID] = 111 where [CountryID] is null

delete from ApplicationLinkUserTypePermission
where ApplicationLinkId in (301,302) and UserTypeId = 3