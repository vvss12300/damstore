﻿INSERT INTO [dbo].[LanguageResource] VALUES ('StoreName','Store Name','Store Name_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('StoreShortName','Store Short Name','Store Short Name_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('Company','Company','Company_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('Brand','Brand','Brand_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('EmailAlertEnable','EmailAlertEnable','EmailAlertEnable_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('NewStore','New Store','New Store_I',null)
GO

Alter table Store
Add Notes nvarchar(300)

Alter table Store
Add City nvarchar(50)
