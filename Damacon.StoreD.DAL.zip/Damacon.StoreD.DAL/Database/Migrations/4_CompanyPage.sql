﻿INSERT INTO [dbo].[LanguageResource] VALUES ('CompanyName','CompanyName','CompanyName_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('CompanyShortName','CompanyShortName','CompanyShortName_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('Iva','Iva','Iva_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('New','New','New_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('Phone','Phone','Phone_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('Fax','Fax','Fax_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('M_CompanyAlreadyExist','Company Already Exist','Company Already Exist_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('NewCompany','New Company','New Company_I',null)
GO

Alter table Company
Add Notes nvarchar(300)
Go