﻿EXEC sp_RENAME 'GoodsType.GoodsType' , 'TypeText', 'COLUMN'
Alter table GoodsType
Add Notes nvarchar(300)

EXEC sp_RENAME 'WorkerTimeType.WorkerTimeType' , 'TypeText', 'COLUMN'
EXEC sp_RENAME 'WorkerTimeType.Note' , 'Notes', 'COLUMN'


INSERT INTO [dbo].[LanguageResource] VALUES ('NewGoodsType','New GoodsType','New GoodsType_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('GoodsTypeText','GoodsType','GoodsType_I',null)

INSERT INTO [dbo].[LanguageResource] VALUES ('NewWorkerTimeType','New WorkerTimeType','New WorkerTimeType_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('WorkerTimeTypeText','WorkerTimeType','WorkerTimeType_I',null)

INSERT INTO [dbo].[LanguageResource] VALUES ('InStatistic','InStatistic','InStatistic_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('InTheStore','InTheStore','InTheStore_I',null)

INSERT INTO [dbo].[LanguageResource] VALUES ('M_GoodsTypeAlreadyExist','GoodsType Already Exist','GoodsType Already Exist_I',null)
INSERT INTO [dbo].[LanguageResource] VALUES ('M_WorkerTimeTypeAlreadyExist','WorkerTimeType Already Exist','WorkerTimeType Already Exist_I',null)
GO


update ApplicationLink set LinkAction ='ManageGoodsTypes' where ID = 108 
update ApplicationLink set LinkAction ='ManageWorkerTimeTypes' where ID = 109 