﻿using Damacon.StoreD.DAL.i18n;

namespace Damacon.StoreD.DAL.Database.EF
{
    public partial class ApplicationLink
    {
        public string DisplayText
        {
            get
            {
                return Resources.GetResource(LanguageResourceID);
            }
        }
    }
}
