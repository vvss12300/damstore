﻿using Damacon.StoreD.DAL.Operations.Concrete;
using Damacon.StoreD.DAL.Operations.Contracts;

namespace Damacon.StoreD.DAL
{
    public class DALFactory
    {
        public static T GetDALObject<T>()
        {
            object dalObject = new object();
            if (typeof(T) == typeof(IUserDAL))
            {
                dalObject = new UserDAL();
            }
            else if (typeof(T) == typeof(ICompanyDAL))
            {
                dalObject = new CompanyDAL();
            }
            else if (typeof(T) == typeof(IStoreDAL))
            {
                dalObject = new StoreDAL();
            }
            else if (typeof(T) == typeof(IGoodsTypeDAL))
            {
                dalObject = new GoodsTypeDAL();
            }
            else if (typeof(T) == typeof(IWorkerTimeTypeDAL))
            {
                dalObject = new WorkerTimeTypeDAL();
            }
            else if (typeof(T) == typeof(IStaticDataDAL))
            {
                dalObject = new StaticDataDAL();
            }
            return (T)(dalObject);
        }
    }
}
