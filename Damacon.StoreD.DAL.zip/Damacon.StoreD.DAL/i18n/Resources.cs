using System;
using Damacon.StoreD.DAL.i18n.Abstract;
using Damacon.StoreD.DAL.i18n.Concrete;
using System.Globalization;
    
namespace Damacon.StoreD.DAL.i18n {
        public class Resources {
            private static IResourceProvider resourceProvider = new DbResourceProvider();

        public static string GetResource(string resourceName)
        {
            return (string)resourceProvider.GetResource(resourceName, CultureInfo.CurrentUICulture.Name);
        }
                
        
        public static string Address {
               get {
                   return (string) resourceProvider.GetResource("Address", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Brand {
               get {
                   return (string) resourceProvider.GetResource("Brand", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string City {
               get {
                   return (string) resourceProvider.GetResource("City", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Company {
               get {
                   return (string) resourceProvider.GetResource("Company", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string CompanyName {
               get {
                   return (string) resourceProvider.GetResource("CompanyName", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string CompanyShortName {
               get {
                   return (string) resourceProvider.GetResource("CompanyShortName", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Country {
               get {
                   return (string) resourceProvider.GetResource("Country", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string CreateNew {
               get {
                   return (string) resourceProvider.GetResource("CreateNew", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Delete {
               get {
                   return (string) resourceProvider.GetResource("Delete", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Disabled {
               get {
                   return (string) resourceProvider.GetResource("Disabled", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Edit {
               get {
                   return (string) resourceProvider.GetResource("Edit", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Email {
               get {
                   return (string) resourceProvider.GetResource("Email", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string EmailAlertEnable {
               get {
                   return (string) resourceProvider.GetResource("EmailAlertEnable", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Enabled {
               get {
                   return (string) resourceProvider.GetResource("Enabled", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string ExportToExcel {
               get {
                   return (string) resourceProvider.GetResource("ExportToExcel", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string ExportToPDF {
               get {
                   return (string) resourceProvider.GetResource("ExportToPDF", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Fax {
               get {
                   return (string) resourceProvider.GetResource("Fax", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Female {
               get {
                   return (string) resourceProvider.GetResource("Female", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string FirstName {
               get {
                   return (string) resourceProvider.GetResource("FirstName", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Gender {
               get {
                   return (string) resourceProvider.GetResource("Gender", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string GenericSearch {
               get {
                   return (string) resourceProvider.GetResource("GenericSearch", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string GoodsTypeText {
               get {
                   return (string) resourceProvider.GetResource("GoodsTypeText", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_About {
               get {
                   return (string) resourceProvider.GetResource("HM_About", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Backup {
               get {
                   return (string) resourceProvider.GetResource("HM_Backup", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Buyer {
               get {
                   return (string) resourceProvider.GetResource("HM_Buyer", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Companies {
               get {
                   return (string) resourceProvider.GetResource("HM_Companies", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Damacon_srl {
               get {
                   return (string) resourceProvider.GetResource("HM_Damacon_srl", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Dashboard {
               get {
                   return (string) resourceProvider.GetResource("HM_Dashboard", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Documents {
               get {
                   return (string) resourceProvider.GetResource("HM_Documents", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_DocumentsRegistration {
               get {
                   return (string) resourceProvider.GetResource("HM_DocumentsRegistration", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_EmailServices {
               get {
                   return (string) resourceProvider.GetResource("HM_EmailServices", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Employees {
               get {
                   return (string) resourceProvider.GetResource("HM_Employees", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_FidelityCardsAndBonus {
               get {
                   return (string) resourceProvider.GetResource("HM_FidelityCardsAndBonus", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Goods {
               get {
                   return (string) resourceProvider.GetResource("HM_Goods", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Languages {
               get {
                   return (string) resourceProvider.GetResource("HM_Languages", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Periods {
               get {
                   return (string) resourceProvider.GetResource("HM_Periods", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_RemoteConnection {
               get {
                   return (string) resourceProvider.GetResource("HM_RemoteConnection", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Report {
               get {
                   return (string) resourceProvider.GetResource("HM_Report", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Reports {
               get {
                   return (string) resourceProvider.GetResource("HM_Reports", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Sales {
               get {
                   return (string) resourceProvider.GetResource("HM_Sales", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Settings {
               get {
                   return (string) resourceProvider.GetResource("HM_Settings", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Store {
               get {
                   return (string) resourceProvider.GetResource("HM_Store", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Stores {
               get {
                   return (string) resourceProvider.GetResource("HM_Stores", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Summary {
               get {
                   return (string) resourceProvider.GetResource("HM_Summary", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Supplier {
               get {
                   return (string) resourceProvider.GetResource("HM_Supplier", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Table {
               get {
                   return (string) resourceProvider.GetResource("HM_Table", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Users {
               get {
                   return (string) resourceProvider.GetResource("HM_Users", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_Version {
               get {
                   return (string) resourceProvider.GetResource("HM_Version", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_WindowsDresser {
               get {
                   return (string) resourceProvider.GetResource("HM_WindowsDresser", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_WorkersTime {
               get {
                   return (string) resourceProvider.GetResource("HM_WorkersTime", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_WorkersTimetable {
               get {
                   return (string) resourceProvider.GetResource("HM_WorkersTimetable", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HM_WorkersTypeTime {
               get {
                   return (string) resourceProvider.GetResource("HM_WorkersTypeTime", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string HomePhone {
               get {
                   return (string) resourceProvider.GetResource("HomePhone", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string InStatistic {
               get {
                   return (string) resourceProvider.GetResource("InStatistic", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string InTheStore {
               get {
                   return (string) resourceProvider.GetResource("InTheStore", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Iva {
               get {
                   return (string) resourceProvider.GetResource("Iva", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_CompanyAlreadyExist {
               get {
                   return (string) resourceProvider.GetResource("M_CompanyAlreadyExist", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_EmailHelpText {
               get {
                   return (string) resourceProvider.GetResource("M_EmailHelpText", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_FieldRequired {
               get {
                   return (string) resourceProvider.GetResource("M_FieldRequired", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_GoodsTypeAlreadyExist {
               get {
                   return (string) resourceProvider.GetResource("M_GoodsTypeAlreadyExist", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_HomePhoneHelpText {
               get {
                   return (string) resourceProvider.GetResource("M_HomePhoneHelpText", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_InactiveUser  {
               get {
                   return (string) resourceProvider.GetResource("M_InactiveUser ", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_IncorrectUserNameorPasssword {
               get {
                   return (string) resourceProvider.GetResource("M_IncorrectUserNameorPasssword", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_InternalServerError {
               get {
                   return (string) resourceProvider.GetResource("M_InternalServerError", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_InvalidEmail {
               get {
                   return (string) resourceProvider.GetResource("M_InvalidEmail", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_InvalidPhoneNumber {
               get {
                   return (string) resourceProvider.GetResource("M_InvalidPhoneNumber", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_InvalidUser {
               get {
                   return (string) resourceProvider.GetResource("M_InvalidUser", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_MobilePhoneHelpText {
               get {
                   return (string) resourceProvider.GetResource("M_MobilePhoneHelpText", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_OnlyNumbersAreAllowed {
               get {
                   return (string) resourceProvider.GetResource("M_OnlyNumbersAreAllowed", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_PasswordHelpText {
               get {
                   return (string) resourceProvider.GetResource("M_PasswordHelpText", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_SpecialCharactersAndSpaceNotAllowed {
               get {
                   return (string) resourceProvider.GetResource("M_SpecialCharactersAndSpaceNotAllowed", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_SpecialCharactersNotAllowed {
               get {
                   return (string) resourceProvider.GetResource("M_SpecialCharactersNotAllowed", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_UserAlreadyExist {
               get {
                   return (string) resourceProvider.GetResource("M_UserAlreadyExist", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_UserNameHelpText {
               get {
                   return (string) resourceProvider.GetResource("M_UserNameHelpText", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string M_WorkerTimeTypeAlreadyExist {
               get {
                   return (string) resourceProvider.GetResource("M_WorkerTimeTypeAlreadyExist", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Male {
               get {
                   return (string) resourceProvider.GetResource("Male", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string MobilePhone {
               get {
                   return (string) resourceProvider.GetResource("MobilePhone", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Name {
               get {
                   return (string) resourceProvider.GetResource("Name", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string New {
               get {
                   return (string) resourceProvider.GetResource("New", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string NewCompany {
               get {
                   return (string) resourceProvider.GetResource("NewCompany", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string NewGoodsType {
               get {
                   return (string) resourceProvider.GetResource("NewGoodsType", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string NewStore {
               get {
                   return (string) resourceProvider.GetResource("NewStore", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string NewUser {
               get {
                   return (string) resourceProvider.GetResource("NewUser", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string NewWorkerTimeType {
               get {
                   return (string) resourceProvider.GetResource("NewWorkerTimeType", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Notes {
               get {
                   return (string) resourceProvider.GetResource("Notes", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Password {
               get {
                   return (string) resourceProvider.GetResource("Password", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Phone {
               get {
                   return (string) resourceProvider.GetResource("Phone", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Prov {
               get {
                   return (string) resourceProvider.GetResource("Prov", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string SearchMinimumCharacters {
               get {
                   return (string) resourceProvider.GetResource("SearchMinimumCharacters", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string SignIn {
               get {
                   return (string) resourceProvider.GetResource("SignIn", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string State {
               get {
                   return (string) resourceProvider.GetResource("State", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string StoreName {
               get {
                   return (string) resourceProvider.GetResource("StoreName", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string StoreShortName {
               get {
                   return (string) resourceProvider.GetResource("StoreShortName", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Surname {
               get {
                   return (string) resourceProvider.GetResource("Surname", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string UploadPhoto {
               get {
                   return (string) resourceProvider.GetResource("UploadPhoto", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string Username {
               get {
                   return (string) resourceProvider.GetResource("Username", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string UserType {
               get {
                   return (string) resourceProvider.GetResource("UserType", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string WorkerTimeTypeText {
               get {
                   return (string) resourceProvider.GetResource("WorkerTimeTypeText", CultureInfo.CurrentUICulture.Name);
               }
            }
            
        
        public static string ZipCode {
               get {
                   return (string) resourceProvider.GetResource("ZipCode", CultureInfo.CurrentUICulture.Name);
               }
            }

        }        
}
