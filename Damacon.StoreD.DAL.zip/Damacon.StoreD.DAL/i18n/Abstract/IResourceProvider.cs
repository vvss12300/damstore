﻿namespace Damacon.StoreD.DAL.i18n.Abstract
{
    public interface IResourceProvider
    {
        object GetResource(string name, string culture);                
    }
}
